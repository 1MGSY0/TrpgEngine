#pragma once

#include <memory>

#include "Engine/EntitySystem/EntityManager.hpp"
#include "Engine/EntitySystem/Entity.hpp"


/**
 * Renders the Inspector UI for a given entity.
 * Dynamically displays known components (Character, Script, etc.)
 * and ignores unknown ones unless extended.
 *
 * @param entity The selected entity.
 * @param em Reference to the active EntityManager.
 */

struct DialogueComponent;
struct CharacterComponent;
struct ChoiceComponent;
struct DiceRollComponent;
struct BackgroundComponent;
struct FlowNodeComponent;
struct UITriggerComponent;
struct SceneMetaComponent;
struct Transform2DComponent;
struct TransformComponent;

void renderDialogueInspector(const std::shared_ptr<DialogueComponent>&);
void renderCharacterInspector(const std::shared_ptr<CharacterComponent>&);
void renderChoiceInspector(const std::shared_ptr<ChoiceComponent>&);
void renderDiceInspector(const std::shared_ptr<DiceRollComponent>&);
void renderBackgroundInspector(const std::shared_ptr<BackgroundComponent>&);
void renderFlowNodeInspector(const std::shared_ptr<FlowNodeComponent>&);
void renderUITriggerInspector(const std::shared_ptr<UITriggerComponent>&);
void renderSceneMetaInspector(const std::shared_ptr<SceneMetaComponent>&);
void renderTransform2DInspector(const std::shared_ptr<Transform2DComponent>&);
void renderTransform3DInspector(const std::shared_ptr<TransformComponent>&);

void renderEntityInspector(Entity entity, EntityManager& em);
