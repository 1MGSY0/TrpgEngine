#pragma once
#include <memory>
class CharacterComponent;

void renderCharacterInspector(std::shared_ptr<CharacterComponent> character);

