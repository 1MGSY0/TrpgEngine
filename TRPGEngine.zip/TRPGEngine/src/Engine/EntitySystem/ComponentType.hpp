#pragma once

#include <memory>
#include <string>
#include <vector>
#include <functional>
#include <json.hpp>

#include "ComponentBase.hpp"

enum class ComponentType {
    Unknown = 0,
    ProjectMetadata,
    Parent,
    Children,
    Character,
    Script,
    Choice,
    Dialogue,
    FlowNode,
    Transform,
    Transform2D,
    UITrigger,
    DiceRoll,
    Background,
    GameState
};


namespace ComponentTypeRegistry {

using LoaderFn = std::function<std::shared_ptr<ComponentBase>(const nlohmann::json&)>;
using ExtensionList = std::vector<std::string>;
using InspectorRendererFn = std::function<void(Entity, std::shared_ptr<ComponentBase>)>;

struct RegisteredComponent {
    LoaderFn loader;
    std::string key;
    InspectorRendererFn inspectorRenderer = nullptr;
};

void registerBuiltins();
const RegisteredComponent* getInfo(ComponentType type);
const std::unordered_map<ComponentType, RegisteredComponent>& getAllInfos();

}
