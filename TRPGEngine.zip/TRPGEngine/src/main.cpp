#include "Core/Application.hpp"

int main() {
    Application app;
    app.run();
    return 0;
}
