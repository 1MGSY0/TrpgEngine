#pragma once
#include <memory>
#include <string>
class ScriptComponent;

void renderScriptInspector(std::shared_ptr<ScriptComponent> script);
