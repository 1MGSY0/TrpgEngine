#include "ComponentType.hpp"
#include "ComponentBase.hpp"
#include "Engine/EntitySystem/Components/CharacterComponent.hpp"
#include "Engine/EntitySystem/Components/ScriptComponent.hpp"
#include "Engine/EntitySystem/Components/ProjectMetaComponent.hpp"
#include "Engine/EntitySystem/Components/ParentComponent.hpp"
#include "Engine/EntitySystem/Components/ChildrenComponent.hpp"
#include "Engine/EntitySystem/Components/DialogueComponent.hpp"
#include "Engine/EntitySystem/Components/FlowNodeComponent.hpp"
#include "Engine/EntitySystem/Components/TransformComponent.hpp"
#include "Engine/EntitySystem/Components/DiceRollComponent.hpp"
#include "Engine/EntitySystem/Components/ChoiceComponent.hpp"
#include "Engine/EntitySystem/Components/UITriggerComponent.hpp"
#include "Engine/EntitySystem/Components/GameStateComponent.hpp"
#include "Engine/EntitySystem/Components/BackgroundComponent.hpp"
#include "Engine/EntitySystem/Components/Transform2DComponent.hpp"

// UI renderers
extern void renderCharacterInspector(const std::shared_ptr<CharacterComponent>&);
extern void renderDialogueInspector(const std::shared_ptr<DialogueComponent>&);
extern void renderChoiceInspector(const std::shared_ptr<ChoiceComponent>&);
extern void renderDiceInspector(const std::shared_ptr<DiceRollComponent>&);
extern void renderBackgroundInspector(const std::shared_ptr<BackgroundComponent>&);
extern void renderFlowNodeInspector(const std::shared_ptr<FlowNodeComponent>&);
extern void renderUITriggerInspector(const std::shared_ptr<UITriggerComponent>&);
extern void renderProjectMetaInspector(const std::shared_ptr<ProjectMetaComponent>&);
extern void renderTransform3DInspector(const std::shared_ptr<TransformComponent>&);
extern void renderTransform2DInspector(const std::shared_ptr<Transform2DComponent>&);


namespace ComponentTypeRegistry {

static std::unordered_map<ComponentType, RegisteredComponent> componentsByType;
static std::unordered_map<std::string, ComponentType> stringToType;

void registerBuiltins() {
    componentsByType.clear();
    stringToType.clear();

    auto registerComponent = [](ComponentType type, const std::string& key, LoaderFn loader, InspectorRendererFn renderer = nullptr) {
        componentsByType[type] = RegisteredComponent{ loader, key, renderer };
        stringToType[key] = type;
    };

    registerComponent(ComponentType::ProjectMetadata, "project",
        [](const nlohmann::json& j) { return ProjectMetaComponent::fromJson(j); },
        [](std::shared_ptr<ComponentBase> base) {
            renderProjectMetaInspector(std::static_pointer_cast<ProjectMetaComponent>(base));
        });

    registerComponent(ComponentType::Parent, "parent",
        [](const nlohmann::json& j) { return ParentComponent::fromJson(j); });

    registerComponent(ComponentType::Children, "children",
        [](const nlohmann::json& j) { return ChildrenComponent::fromJson(j); });

    registerComponent(ComponentType::Character, "character",
        [](const nlohmann::json& j) { return CharacterComponent::fromJson(j); },
        [](std::shared_ptr<ComponentBase> base) {
            renderCharacterInspector(std::static_pointer_cast<CharacterComponent>(base));
        });

    registerComponent(ComponentType::Script, "script",
        [](const nlohmann::json& j) { return ScriptComponent::fromJson(j); });

    registerComponent(ComponentType::Dialogue, "dialogue",
        [](const nlohmann::json& j) { return DialogueComponent::fromJson(j); },
        [](std::shared_ptr<ComponentBase> base) {
            renderDialogueInspector(std::static_pointer_cast<DialogueComponent>(base));
        });

    registerComponent(ComponentType::FlowNode, "flownode",
        [](const nlohmann::json& j) { return FlowNodeComponent::fromJson(j); },
        [](std::shared_ptr<ComponentBase> base) {
            renderFlowNodeInspector(std::static_pointer_cast<FlowNodeComponent>(base));
        });

    registerComponent(ComponentType::Transform, "transform",
        [](const nlohmann::json& j) { return TransformComponent::fromJson(j); },
        [](std::shared_ptr<ComponentBase> comp) {
            renderTransform3DInspector(std::static_pointer_cast<TransformComponent>(comp));
        });

    registerComponent(ComponentType::Transform2D, "transform2d",
        [](const nlohmann::json& j) { return Transform2DComponent::fromJson(j); },
        [](Entity, std::shared_ptr<ComponentBase> comp) {
            renderTransform2DInspector(std::static_pointer_cast<Transform2DComponent>(comp));
        });

    registerComponent(ComponentType::Choice, "choice",
        [](const nlohmann::json& j) { return ChoiceComponent::fromJson(j); },
        [](std::shared_ptr<ComponentBase> base) {
            renderChoiceInspector(std::static_pointer_cast<ChoiceComponent>(base));
        });

    registerComponent(ComponentType::DiceRoll, "dice",
        [](const nlohmann::json& j) { return DiceRollComponent::fromJson(j); },
        [](std::shared_ptr<ComponentBase> base) {
            renderDiceInspector(std::static_pointer_cast<DiceRollComponent>(base));
        });

    registerComponent(ComponentType::UITrigger, "uitrigger",
        [](const nlohmann::json& j) { return UITriggerComponent::fromJson(j); },
        [](std::shared_ptr<ComponentBase> base) {
            renderUITriggerInspector(std::static_pointer_cast<UITriggerComponent>(base));
        });

    registerComponent(ComponentType::GameState, "gamestate",
        [](const nlohmann::json& j) { return GameStateComponent::fromJson(j); });

    registerComponent(ComponentType::Background, "background",
        [](const nlohmann::json& j) { return BackgroundComponent::fromJson(j); },
        [](std::shared_ptr<ComponentBase> base) {
            renderBackgroundInspector(std::static_pointer_cast<BackgroundComponent>(base));
        });
}

const RegisteredComponent* getInfo(ComponentType type) {
    auto it = componentsByType.find(type);
    return it != componentsByType.end() ? &it->second : nullptr;
}

const std::unordered_map<ComponentType, RegisteredComponent>& getAllInfos() {
    return componentsByType;
}

}
