#pragma once
#include <string>

class RuntimeApp {
public:
    void run(const std::string& dataFilePath);
};