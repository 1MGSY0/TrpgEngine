#include "UI/EditorUI.hpp"
#include "EntityInspectorPanel.hpp"
#include "Engine/EntitySystem/EntityManager.hpp"
#include "Engine/EntitySystem/Components/CharacterComponent.hpp"
#include "Engine/EntitySystem/Components/ScriptComponent.hpp"
#include "Engine/EntitySystem/Components/DialogueComponent.hpp"
#include "Engine/EntitySystem/Components/ChoiceComponent.hpp"
#include "Engine/EntitySystem/Components/DiceRollComponent.hpp"
#include "Engine/EntitySystem/Components/BackgroundComponent.hpp"
#include "Engine/EntitySystem/Components/Transform2DComponent.hpp"
#include "Engine/EntitySystem/Components/TransformComponent.hpp"
#include "Engine/EntitySystem/Components/FlowNodeComponent.hpp"
#include "Engine/EntitySystem/Components/UITriggerComponent.hpp"

#include "UI/SceneManager.hpp"

#include <imgui.h>
#include <fstream>
#include <memory>
#include <cstring>
#include <filesystem>
#include <misc/cpp/imgui_stdlib.h> 

void renderEntityInspector(Entity entity, EntityManager& em) {
    if (entity == INVALID_ENTITY) {
        ImGui::Text("No entity selected.");
        return;
    }

    // 1. ADD COMPONENT SECTION
    if (ImGui::CollapsingHeader("Add Component", ImGuiTreeNodeFlags_DefaultOpen)) {
        static int selectedIndex = 0;
        static std::vector<std::string> keys;
        static std::vector<ComponentType> types;

        // Build list once
        if (keys.empty()) {
            for (const auto& [type, info] : ComponentTypeRegistry::getAllInfos()) {
                keys.push_back(info.key);
                types.push_back(type);
            }
        }

        std::vector<const char*> cStrs;
        for (const auto& k : keys) cStrs.push_back(k.c_str());

        ImGui::Combo("Component", &selectedIndex, cStrs.data(), static_cast<int>(cStrs.size()));
        if (ImGui::Button("Attach")) {
            auto selectedType = types[selectedIndex];
            const auto& info = ComponentTypeRegistry::getInfo(selectedType);
            if (info && info->loader) {
                auto component = info->loader(nlohmann::json{});
                em.addComponent(entity, component);
            }
        }
    }

    ImGui::Separator();

    // 2. DISPLAY EXISTING COMPONENTS
    auto components = em.getAllComponents(entity);
    if (components.empty()) {
        ImGui::Text("This entity has no components.");
        return;
    }

    for (auto& comp : components) {
        ComponentType type = comp->getType();
        const auto* info = ComponentTypeRegistry::getInfo(type);
        if (!info) continue;

        ImGui::PushID(info->key.c_str());
        if (ImGui::CollapsingHeader(info->key.c_str(), ImGuiTreeNodeFlags_DefaultOpen)) {
            if (info->inspectorRenderer) {
                info->inspectorRenderer(entity, comp);
            } else {
                ImGui::Text("No UI renderer for this component.");
            }
        }
        ImGui::PopID();
        ImGui::Separator();
    }
}

void renderScriptInspector(std::shared_ptr<ScriptComponent> script) {
    if (!script) {
        ImGui::Text("No script selected.");
        return;
    }

    ImGui::InputText("Name", &script->name);
    ImGui::InputText("Script File", &script->scriptPath);
}

void renderCharacterInspector(std::shared_ptr<CharacterComponent> character) {
    if (!character) {
        ImGui::Text("No character selected.");
        return;
    }

    // Editable name
    ImGui::InputText("Name", &character->name);

    // Editable icon image path
    ImGui::InputText("Icon Image", &character->iconImage);

    // --- State Images ---
    if (ImGui::CollapsingHeader("State Images")) {
        for (auto& [state, path] : character->stateImages) {
            ImGui::InputText(state.c_str(), &path);
        }

        static std::string newState;
        static std::string newPath;

        ImGui::InputText("State", &newState);
        ImGui::InputText("Path", &newPath);

        if (ImGui::Button("Add State")) {
            if (!newState.empty() && !newPath.empty()) {
                character->stateImages[newState] = newPath;
                newState.clear();
                newPath.clear();
            }
        }
    }

    // --- Stats ---
    if (ImGui::CollapsingHeader("Stats")) {
        for (auto& [key, value] : character->stats) {
            int v = value;
            if (ImGui::DragInt(key.c_str(), &v)) {
                character->stats[key] = v;
            }
        }

        static std::string newStatKey;
        static int newStatValue = 0;

        ImGui::InputText("New Stat", &newStatKey);
        ImGui::DragInt("Value", &newStatValue);
        if (ImGui::Button("Add Stat")) {
            if (!newStatKey.empty()) {
                character->stats[newStatKey] = newStatValue;
                newStatKey.clear();
                newStatValue = 0;
            }
        }
    }
}

// Dialogue
void renderDialogueInspector(const std::shared_ptr<DialogueComponent>& comp) {
    ImGui::Text("Dialogue Lines:");
    for (size_t i = 0; i < comp->lines.size(); ++i) {
        char buffer[256];
        strncpy(buffer, comp->lines[i].c_str(), sizeof(buffer));
        buffer[255] = '\0';
        if (ImGui::InputText(("Line " + std::to_string(i)).c_str(), buffer, sizeof(buffer)))
            comp->lines[i] = buffer;
    }
    if (ImGui::Button("Add Line"))
        comp->lines.push_back("New line...");
}


// Choice
void renderChoiceInspector(const std::shared_ptr<ChoiceComponent>& comp) {
    ImGui::Text("Choice Options:");
    for (size_t i = 0; i < comp->options.size(); ++i) {
        char buffer[256];
        strncpy(buffer, comp->options[i].text.c_str(), sizeof(buffer));
        buffer[255] = '\0';

        if (ImGui::InputText(("Option " + std::to_string(i)).c_str(), buffer, sizeof(buffer))) {
            comp->options[i].text = buffer;
        }

        ImGui::Text("Trigger: %d", static_cast<int>(comp->options[i].trigger));
        ImGui::Separator();
    }

    if (ImGui::Button("Add Option")) {
        comp->options.push_back({"New choice", ComponentType::Unknown});
    }
}
// Dice Roll
void renderDiceInspector(const std::shared_ptr<DiceRollComponent>& comp) {
    ImGui::Text("Dice Roll Settings");

    // Dice sides (e.g. D6, D20)
    ImGui::InputInt("Dice Sides", &comp->sides);

    // Success threshold
    ImGui::InputInt("Success Threshold", &comp->threshold);

    // Flow triggers
    char bufferSuccess[256];
    strncpy(bufferSuccess, comp->onSuccess.c_str(), sizeof(bufferSuccess));
    bufferSuccess[255] = '\0';
    if (ImGui::InputText("On Success Trigger", bufferSuccess, sizeof(bufferSuccess))) {
        comp->onSuccess = bufferSuccess;
    }

    char bufferFailure[256];
    strncpy(bufferFailure, comp->onFailure.c_str(), sizeof(bufferFailure));
    bufferFailure[255] = '\0';
    if (ImGui::InputText("On Failure Trigger", bufferFailure, sizeof(bufferFailure))) {
        comp->onFailure = bufferFailure;
    }

    ImGui::Separator();
    ImGui::TextWrapped("Dice will roll a value between 1 and 'sides'. "
                       "If result >= threshold, OnSuccess will be triggered; otherwise, OnFailure.");
}

// Background
void renderBackgroundInspector(const std::shared_ptr<BackgroundComponent>& comp) {
    char buffer[256];
    strncpy(buffer, comp->assetPath.c_str(), sizeof(buffer));
    buffer[255] = '\0';

    if (ImGui::InputText("Texture Path", buffer, sizeof(buffer))) {
        comp->assetPath = buffer;
    }

    ImGui::TextWrapped("Enter a relative or absolute path to the background texture (e.g., 'Assets/Backgrounds/scene1.png').");
}

// FlowNode

void renderFlowNodeInspector(std::shared_ptr<FlowNodeComponent> comp, Entity nodeId) {
    auto& em = EntityManager::get();
    ImGui::Text("🎬 Flow Node: %s", comp->name.c_str());
    ImGui::Separator();

    char nameBuffer[128];
    strncpy(nameBuffer, comp->name.c_str(), sizeof(nameBuffer));
    nameBuffer[127] = '\0';
    if (ImGui::InputText("Name", nameBuffer, sizeof(nameBuffer))) {
        comp->name = nameBuffer;
    }

    ImGui::Checkbox("Start Node", &comp->isStart);
    ImGui::SameLine();
    ImGui::Checkbox("End Node", &comp->isEnd);

    ImGui::InputInt("Next Auto Node", reinterpret_cast<int*>(&comp->nextNode));

    // Characters
    ImGui::Separator();
    ImGui::Text("🎭 Characters in Scene:");
    for (int i = 0; i < comp->characters.size(); ++i) {
        Entity charId = comp->characters[i];
        ImGui::BulletText("ID %d", charId);
        ImGui::SameLine();
        if (ImGui::SmallButton(("Inspect##char" + std::to_string(charId)).c_str())) {
            EditorUI::get()->setSelectedEntity(charId);
        }
        ImGui::SameLine();
        if (ImGui::SmallButton(("Remove##char" + std::to_string(charId)).c_str())) {
            comp->characters.erase(comp->characters.begin() + i);
            i--;
        }
    }
    if (ImGui::Button("➕ Add Character")) {
        Entity newChar = EntityManager::get().createEntity();
        auto c = std::make_shared<CharacterComponent>();
        EntityManager::get().addComponent(newChar, c);
        comp->characters.push_back(newChar);
        EditorUI::get()->setSelectedEntity(newChar);
    }

    // Backgrounds
    ImGui::Separator();
    ImGui::Text("🖼️ Background(s):");
    for (int i = 0; i < comp->backgroundEntities.size(); ++i) {
        Entity bgId = comp->backgroundEntities[i];
        ImGui::BulletText("ID %d", bgId);
        ImGui::SameLine();
        if (ImGui::SmallButton(("Inspect##bg" + std::to_string(bgId)).c_str())) {
            EditorUI::get()->setSelectedEntity(bgId);
        }
        ImGui::SameLine();
        if (ImGui::SmallButton(("Remove##bg" + std::to_string(bgId)).c_str())) {
            comp->backgroundEntities.erase(comp->backgroundEntities.begin() + i);
            i--;
        }
    }
    if (ImGui::Button("➕ Add Background")) {
        Entity newBg = EntityManager::get().createEntity();
        auto b = std::make_shared<BackgroundComponent>();
        EntityManager::get().addComponent(newBg, b);
        comp->backgroundEntities.push_back(newBg);
        EditorUI::get()->setSelectedEntity(newBg);
    }

    // Event Sequence
    ImGui::Separator();
    ImGui::Text("📜 Event Flow (Ordered):");

    static int dragSrcIndex = -1;
    for (int i = 0; i < comp->eventSequence.size(); ++i) {
        Entity eventId = comp->eventSequence[i];
        ImGui::PushID(i);

        if (ImGui::Selectable(("Event " + std::to_string(i) + " [ID " + std::to_string(eventId) + "]").c_str())) {
            EditorUI::get()->setSelectedEntity(eventId);
        }

        if (ImGui::BeginDragDropSource()) {
            dragSrcIndex = i;
            ImGui::Text("Moving Event %d", i);
            ImGui::SetDragDropPayload("EVENT_REORDER", &i, sizeof(int));
            ImGui::EndDragDropSource();
        }

        if (ImGui::BeginDragDropTarget()) {
            if (const ImGuiPayload* payload = ImGui::AcceptDragDropPayload("EVENT_REORDER")) {
                int src = *(const int*)payload->Data;
                if (src != i && src >= 0 && src < comp->eventSequence.size()) {
                    std::swap(comp->eventSequence[src], comp->eventSequence[i]);
                }
            }
            ImGui::EndDragDropTarget();
        }

        ImGui::SameLine();
        if (ImGui::SmallButton("Remove")) {
            comp->eventSequence.erase(comp->eventSequence.begin() + i);
            i--;
        }

        ImGui::PopID();
    }

    if (ImGui::Button("➕ Add Empty Event Slot")) {
        comp->eventSequence.push_back(INVALID_ENTITY);
    }

    // Drop-down to assign an existing or create a new event entity
    if (!comp->eventSequence.empty() && comp->eventSequence.back() == INVALID_ENTITY) {
        ImGui::Separator();
        ImGui::Text("⚙️ Assign Event to Last Empty Slot:");

        static int selectedType = 0;
        const char* options[] = { "Dialogue", "Choice", "DiceRoll", "UITrigger" };
        ImGui::Combo("Event Type", &selectedType, options, IM_ARRAYSIZE(options));

        if (ImGui::Button("➕ Create New Event")) {
            Entity newEvent = EntityManager::get().createEntity();
            switch (selectedType) {
                case 0: EntityManager::get().addComponent(newEvent, std::make_shared<DialogueComponent>()); break;
                case 1: EntityManager::get().addComponent(newEvent, std::make_shared<ChoiceComponent>()); break;
                case 2: EntityManager::get().addComponent(newEvent, std::make_shared<DiceRollComponent>()); break;
                case 3: EntityManager::get().addComponent(newEvent, std::make_shared<UITriggerComponent>()); break;
            }
            comp->eventSequence.back() = newEvent;
            EditorUI::get()->setSelectedEntity(newEvent);
        }

        if (ImGui::Button("📁 Select Existing Event")) {
            // Future implementation: File picker or asset browser
        }
    }
}

// UITrigger
void renderUITriggerInspector(const std::shared_ptr<UITriggerComponent>& comp) {
    char labelBuf[128];
    strncpy(labelBuf, comp->label.c_str(), sizeof(labelBuf));
    labelBuf[127] = '\0';
    if (ImGui::InputText("Button Label", labelBuf, sizeof(labelBuf))) {
        comp->label = labelBuf;
    }

    ImGui::Separator();

    // Fetch all FlowNode names for dropdown
    auto& em = EntityManager::get();
    auto entities = em.getAllEntities();
    std::vector<std::string> flowNames;

    for (Entity e : entities) {
        auto flow = em.getComponent<FlowNodeComponent>(e);
        if (flow && !flow->name.empty())
            flowNames.push_back(flow->name);
    }

    // Find currently selected index
    int currentIndex = -1;
    for (size_t i = 0; i < flowNames.size(); ++i) {
        if (flowNames[i] == comp->actionTarget) {
            currentIndex = (int)i;
            break;
        }
    }

    std::vector<const char*> labels;
    for (const auto& name : flowNames)
        labels.push_back(name.c_str());

    if (ImGui::Combo("Target Scene", &currentIndex, labels.data(), static_cast<int>(labels.size()))) {
        comp->actionTarget = flowNames[currentIndex];
    }

    if (ImGui::IsItemHovered())
        ImGui::SetTooltip("Trigger will route to the selected FlowNode by name.");
}


// Transform
void renderTransform2DInspector(const std::shared_ptr<Transform2DComponent>& comp) {
    ImGui::Text("Transform 2D");
    ImGui::DragFloat2("Position", &comp->position.x, 1.0f);
    ImGui::DragFloat2("Size", &comp->size.x, 1.0f);
    ImGui::DragFloat2("Scale", &comp->scale.x, 0.01f, 0.0f, 10.0f);
    ImGui::DragFloat("Rotation", &comp->rotation, 1.0f, -360.0f, 360.0f);
}

void renderTransform3DInspector(const std::shared_ptr<TransformComponent>& comp) {
    ImGui::Text("Transform 3D");
    ImGui::DragFloat3("Position", &comp->position.x, 0.1f);
    ImGui::DragFloat3("Rotation", &comp->rotation.x, 1.0f);
    ImGui::DragFloat3("Scale",    &comp->scale.x, 0.01f, 0.0f, 10.0f);
}